let i = 0; //Baslangic Noqtesi
let images = [];
let time = 5000;

//Sekiller
images[0] = '1.jpg';
images[1] = '2.jpeg';
images[2] = '3.jpg';

onload = () =>{
  move();
  changeImg();
  frame();
}
// Sekillerin deyismesi 
function changeImg(){
    document.slide.src = images[i];

    if(i < images.length - 1){
        i++;
    }else {
         i = 0;
    }

    setTimeout("changeImg()", time);
}

function changeImgR(){
    document.slide.src = images[i];
    
     if(i < images.length - 1){
        i++;
    } else {
         i = 0;
    }
}

function changeImgL(){
    document.slide.src = images[i];
    
    if(i < images.length - 1){
       i++;
   } else {
    i = 0;
   }
}





// Progress bar
function move() {
  if (i == 0) {
    i = 1;
    let elem = document.getElementById("myBar");
    let width = 1;
    let id = setInterval(frame, 50);
    function frame() {
      if (width >= 100) {
        document.querySelector("#myBar").style.width = 0;
     
        clearInterval(id);
        i = 0;
      } else {
        width++;
        elem.style.width = width + "%";
      }
    }
  }
}